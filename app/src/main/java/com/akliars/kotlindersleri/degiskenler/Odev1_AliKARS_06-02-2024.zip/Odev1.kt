package com.akliars.kotlindersleri.degiskenler

fun main() {
    val ilce = "Başiskele"
    val kita = "Asya"
    val faks = 2620202020
    val postaKodu = 41140
    val instaAdresi = "ornek_4141"
    var calistiginBolum = "IT Departmanı"
    var urunMiktari = 13
    var musteriSoyadi = "Şaşmaz"
    var odemeMiktari = 15600
    var dogumTarihi = 1941
    var borc = 315.25
    var medeniHal = "Bekar"
    var videoYorumu = "Lorem ipsum dolor sit amet "
    var odemeSaati = "19:32"
    var eftMiktari = 1453.35f
    var satilanMiktar = 1234
    var telefonModeli = "15 Pro MAX"
    var dergiAdi = "Times"
    val basimTarihi = "01-02-2025"
    var zamMiktari = 1250
    val daireSayisi = 60
    val enlem = "32°52'21.67'"
    val boylam = "32°52'21.67''"
    val yemekAdi = "Sac Kavurma"
    var urunFiyati = 15.92
    var sirketAdi = "Turkcell"
    var videoAdi = "Android Bootcamp Eğitim Videosu"
    var muzikSuresi = "3:25"
    var mekanPuani = 7.5
    var dosyaAdi = "Yeni Klasör"
    var resimFormati = ".jpg"
    var renk = "Mavi"
    var renkKodu = "#0216ff"
    var bilgisayarModel = "Inspiron n5010"
    var ekranBoyutu = "1920 x 1080"
    var kullanimSuresi = 150
    var basinc = 1.5
    var etkinlikGunu = "Salı"
    var odemeGunu  = "Perşembe"
    var yolculukCikisTarihi = "01-11-2024"
    var mahalleAdi = "Fatih"
    var otobusHatti = "550s"
    var kullanilanDakika = 41
    val kargoTakipNo = 120455649
    var kuponSuresi = 3
    val kuponKodu = "05asda468a2qrqw"
    val faturaTarihi = "15-02-2024"

    println("İlçe                       : $ilce")
    println("Kıta                       : $kita")
    println("Faks                       : $faks")
    println("Posta Kodu                 : $postaKodu")
    println("Instagram Adresi           : $instaAdresi")
    println("Çalıştığın Bölüm           : $calistiginBolum")
    println("Ürün Miktarı               : $urunMiktari")
    println("Müşteri Soyadı             : $musteriSoyadi")
    println("Ödeme Miktarı              : $odemeMiktari")
    println("Doğum Tarihi               : $dogumTarihi")
    println("Borç                       : $borc")
    println("Medeni Hal                 : $medeniHal")
    println("Video Yorumu               : $videoYorumu")
    println("Ödeme Saati                : $odemeSaati")
    println("Eft Miktarı                : $eftMiktari")
    println("Satılan Miktar             : $satilanMiktar")
    println("Telefon Modeli             : $telefonModeli")
    println("Dergi Adı                  : $dergiAdi")
    println("Basım Tarihi               : $basimTarihi")
    println("Zam Miktarı                : $zamMiktari")
    println("Daire Sayısı               : $daireSayisi")
    println("Enlem                      : $enlem")
    println("Boylam                     : $boylam")
    println("Yemek Adı                  : $yemekAdi")
    println("Ürün Fiyatı                : $urunFiyati")
    println("Şirket                     : $sirketAdi")
    println("Video Adı                  : $videoAdi")
    println("Müzik Süresi               : $muzikSuresi")
    println("Mekan Puanı                : $mekanPuani")
    println("Dosya Adı                  : $dosyaAdi")
    println("Resim Formatı              : $resimFormati")
    println("Renk                       : $renk")
    println("Renk Kodu                  : $renkKodu")
    println("Bilgisayar Modeli          : $bilgisayarModel")
    println("Ekran Boyutu               : $ekranBoyutu")
    println("Kullanım Süresi            : $kullanimSuresi")
    println("Basınç                     : $basinc")
    println("Etkinlik Günü              : $etkinlikGunu")
    println("Ödeme Günü                 : $odemeGunu")
    println("Yolculuk Çıkış Tarihi      : $yolculukCikisTarihi")
    println("Mahalle Adı                : $mahalleAdi")
    println("Otobüs Hattı               : $otobusHatti")
    println("Kullanılan Dakika          : $kullanilanDakika")
    println("Kargo Takip No             : $kargoTakipNo")
    println("Kupon Süresi               : $kuponSuresi")
    println("Kupon Kodu                 : $kuponKodu")
    println("Fatura Tarihi              : $faturaTarihi")

    println("----------------------------------------------")
    println("+ Ödev1 / Ali Kars / 06-02-2024")
    println("----------------------------------------------")










}